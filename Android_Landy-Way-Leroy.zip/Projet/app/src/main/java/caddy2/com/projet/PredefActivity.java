package caddy2.com.projet;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Paint;
import android.os.Vibrator;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class PredefActivity extends AppCompatActivity {



    private BDD db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_predef);
        db = new BDD(this);
        db.open();


        fillData();
        Log.d("Data update", "updateoncreate");
        Log.d("db", db.toString());


    }

    public void fillData(){
        Cursor test = db.fetchAllItems("listepredef");
        startManagingCursor(test);
        String[] from = new String[]{BDD.KEY_NAME};
        Log.d("dbname", from[0]);
        int[] to = new int[]{R.id.rowTextView};
        SimpleCursorAdapter aa = new SimpleCursorAdapter(this, R.layout.nom, test, from, to);
        ListView itemsList = (ListView) findViewById(R.id.predefitem);

        itemsList.setAdapter(aa);
        Log.d("Data update", "update");


        itemsList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

                TextView item2 = (TextView) view.findViewById(R.id.rowTextView);
                final Cursor c4 = db.fetchItemByName(item2.getText().toString(), "listepredef");

                new AlertDialog.Builder(PredefActivity.this)
                        .setTitle("Supprimer item")
                        .setMessage("Etes vous vraiment sûr(e) de supprimer cet item?")
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                deletepred(Integer.valueOf(c4.getString(c4.getColumnIndex(db.KEY_ROWID))));
                            }
                        })
                        .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // do nothing
                            }
                        })
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .show();

                return true;
            }

        });


        itemsList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                TextView item2 = (TextView) view.findViewById(R.id.rowTextView);
                Cursor c3 = db.fetchItemByName(item2.getText().toString(), "listepredef");

               /* if(c3 != null && c3.moveToFirst()){
                    Log.d("", "pas vide!!!!!!!");
                }
                else{
                    Log.d("","vide ;(");
                }*/
                if (!c3.isNull(c3.getColumnIndex(db.KEY_ROWID))) {

                    if (!db.exist("listeuser", c3.getString(c3.getColumnIndex(db.KEY_NAME)))) {
                        db.createitem("listeuser", c3.getString(c3.getColumnIndex(db.KEY_NAME)));
                    } else {
                        Cursor c4 = db.fetchItemByName(item2.getText().toString(), "listeuser");
                        db.updateQuantite(Integer.valueOf(c4.getString(c4.getColumnIndex(db.KEY_ROWID))), Integer.valueOf(c4.getString(c4.getColumnIndex(db.KEY_QUANTITY))) + 1);
                    }
                } else {

                }
            }

        });




    }

    public void createitem(String nom){
        db.createitem("listepredef", nom);
        fillData();
    }

    public void deletepred(int id){
        Long valeur = Long.valueOf(id);
        db.deletepredef(valeur.longValue());
        fillData();
    }

    public void deleteAllpred(){
        Cursor test = db.fetchAllItems("listepredef");
        if(test.moveToFirst()){
            do {
                Long id = Long.valueOf(test.getString(test.getColumnIndex(db.KEY_ROWID)));
                db.deletepredef(id);
            } while(test.moveToNext());
        }
        fillData();
    }


    public void addTask(View view){
        final EditText varEditText = (EditText) findViewById(R.id.editText);

        if("".equals(varEditText.getText().toString())){

        }
        else{
            createitem(varEditText.getText().toString());
            fillData();
            Log.d("Data update", "update");
            varEditText.setText("");
        }
    }


    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu2, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.listusermenu:
                Intent nouveauEcran = new Intent(PredefActivity.this, MainActivity.class);
                startActivity(nouveauEcran);
                return true;
            case R.id.deletepredef:
                deleteAllpred();
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
