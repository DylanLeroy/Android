package caddy2.com.projet;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by dylanl on 30/03/2017.
 */

public class BDD {
    public static final String KEY_ROWID = "_id";
    public static final String KEY_NAME = "nom";
    public static final String KEY_QUANTITY = "quantite";
    public static final String KEY_BARRE = "barre";

    public static final String TAG = "BDD";
    private DatabaseHelper dbhelp;
    private SQLiteDatabase db;

    private static final String DATABASE_CREATE1 = "create table listeuser(_id integer primary key autoincrement, nom text not null, quantite int not null DEFAULT 1, barre int not null DEFAULT 0);";
    private static final String DATABASE_CREATE2 = "create table listepredef(_id integer primary key autoincrement, nom text not null);";
    private static final String DATABASE_NAME = "caddy";
    private static final String DATABASE_TAHLE1 = "listeuser";
    private static final String DATABASE_TAHLE2 = "listepredef";
    private static final int DATABASE_VERSION = 2;

    private final Context mCtx;

    private static class DatabaseHelper extends SQLiteOpenHelper{
        DatabaseHelper(Context context) { super(context,DATABASE_NAME, null, DATABASE_VERSION);}

        @Override
        public void onCreate(SQLiteDatabase db2){
            db2.execSQL(DATABASE_CREATE1);
            db2.execSQL(DATABASE_CREATE2);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
                    + newVersion + ", which will destroy all old data");
            db.execSQL("DROP TABLE IF EXISTS listeuser");
            db.execSQL("DROP TABLE IF EXISTS listepredef");
            onCreate(db);
        }
    }

    public BDD(Context ctx) {
        this.mCtx = ctx;
    }

    public BDD open() throws SQLException {
        dbhelp = new DatabaseHelper(mCtx);
        db = dbhelp.getWritableDatabase();
        return this;
    }

    public void close() {
        dbhelp.close();
    }


    public void createitem(String table, String nom){
        String query = "insert into " + table + "(nom) values('"+nom+"');";
        Cursor c = db.rawQuery(query, null);
        Log.d("statut", "créé: "+query);
        Log.d("Curseur: ", c.toString());


        if (c != null) {
            c.moveToFirst();
        }

        /*Cursor cursor = db.rawQuery("SELECT SUM(odometer) as odometer FROM tripmileagetable where date like '2012-07%';", null);
        int sum = 0;
        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    sum = cursor.getInt(0);
                }
            } finally {
                cursor.close();
            }
        }*/
    }

    public Cursor deleteitemuser(long rowId) {

        String query = "update listeuser set quantite = 0 where _id = "+rowId+";";
        Cursor c = db.rawQuery(query, null);
        if (c != null) {
            c.moveToFirst();
        }
        return c;
    }

    public Cursor deletepredef(long rowId){
        String query = "delete from listepredef where _id = "+rowId+";";
        Cursor c = db.rawQuery(query, null);
        if (c != null) {
            c.moveToFirst();
        }
        return c;
    }

    public Cursor fetchAllItems(String table) {
        String query;
        if(table=="listeuser"){
        query = "select _id,nom,quantite from "+table+";";}
        else{
            query = "select _id,nom from "+table+";";
        }
        Log.d("exec:", query);
        return db.rawQuery(query, null);

    }


    public Cursor fetchItem(long rowId, String table) throws SQLException {

        Cursor mCursor = db.rawQuery("select * from "+table+" where _id = "+rowId+";", null);
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;

    }

    public Cursor fetchItemByName(String name2, String table) throws SQLException {
        String query = "select * from "+table+" where nom = '"+name2+"';";
        Cursor mCursor = db.rawQuery(query, null);
        Log.d("query: ", query);
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;

    }

    public Cursor fetchItemwherebody0() throws SQLException {



        Cursor c = db.rawQuery("select * from listeuser where quantite > 0;", null);
        if (c != null) {
            c.moveToFirst();
        }
        return c;

    }

    public Cursor updateQuantite(long rowId, int quantite) {
        Cursor c = db.rawQuery("update listeuser set quantite = "+quantite+" where _id = "+rowId+";", null);
        if (c != null) {
            c.moveToFirst();
        }
        return (c);
    }

    public Cursor barre(long rowId){
        Cursor c = db.rawQuery("update listeuser set barre = 1 where _id = "+rowId+";", null);
        if (c != null) {
            c.moveToFirst();
        }
        return c;
    }

    public Cursor debarre(long rowId){
        Cursor c = db.rawQuery("update listeuser set barre = 0 where _id = "+rowId+";", null);
        if (c != null) {
            c.moveToFirst();
        }
        return c;
    }

    public boolean exist(String table, String name){
        Cursor c = fetchItemByName(name,table);
        if (c.getCount()==0){
            return false;
        }
        else{
            return true;
        }
    }


}
