package caddy2.com.projet;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by dylanl on 30/03/2017.
 */

public class BDD {
    public static final String KEY_ROWID = "_id";
    public static final String KEY_NAME = "nom";
    public static final String KEY_QUANTITY = "quantite";
    public static final String KEY_BARRE = "barre";

    public static final String TAG = "BDD";
    private DatabaseHelper dbhelp;
    private SQLiteDatabase db;

    private static final String DATABASE_CREATE1 = "create table listeuser (_id integer primary key autoincrement, nom text not null, quantite int not null DEFAULT 1);";
    private static final String DATABASE_CREATE2 = "create table listepredef (_id integer primary key autoincrement, nom text not null);";
    private static final String DATABASE_NAME = "caddy";
    private static final String DATABASE_TAHLE1 = "listeuser";
    private static final String DATABASE_TAHLE2 = "listepredef";
    private static final int DATABASE_VERSION = 2;

    private final Context mCtx;

    private static class DatabaseHelper extends SQLiteOpenHelper{
        DatabaseHelper(Context context) { super(context,DATABASE_NAME, null, DATABASE_VERSION);}

        @Override
        public void onCreate(SQLiteDatabase db2){
            db2.execSQL(DATABASE_CREATE1);
            db2.execSQL(DATABASE_CREATE2);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
                    + newVersion + ", which will destroy all old data");
            db.execSQL("DROP TABLE IF EXISTS listeuser");
            db.execSQL("DROP TABLE IF EXISTS listepredef");
            onCreate(db);
        }
    }

    public BDD(Context ctx) {
        this.mCtx = ctx;
    }

    public BDD open() throws SQLException {
        dbhelp = new DatabaseHelper(mCtx);
        db = dbhelp.getWritableDatabase();
        return this;
    }

    public void close() {
        dbhelp.close();
    }


    public void createitem(String table, String nom){
        String query = "insert into " + table + "(nom) values('"+nom+"')";
        Cursor c = db.rawQuery(query, new String[]{});
        Log.d("statut", "créé: "+query);
        Log.d("Curseur: ", c.toString());
    }

    public Cursor deleteitemuser(long rowId) {

        return db.rawQuery("update listeuser set quantite = 0 where _id = "+rowId, new String[]{});
    }

    public Cursor deletepredef(long rowId){
        return db.rawQuery("delete from listepredef where _id = "+rowId, new String[]{});
    }

    public Cursor fetchAllItems(String table) {
        String query = "select _id,* from "+table;
        Log.d("exec:", query);
        return db.rawQuery(query, new String[]{});

    }


    public Cursor fetchItem(long rowId, String table) throws SQLException {

        Cursor mCursor = db.rawQuery("select * from "+table+" where _id = "+rowId, new String[]{});
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;

    }

    public Cursor fetchItemByName(String name2, String table) throws SQLException {

        Cursor mCursor = db.rawQuery("select * from "+table+" where nom = '"+name2+"'", new String[]{});
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;

    }

    public Cursor fetchItemwherebody0() throws SQLException {



        Cursor c = db.rawQuery("select * from listeuser where quantite > 0", new String[]{});
        if (c != null) {
            c.moveToFirst();
        }
        return c;

    }

    public Cursor updateQuantite(long rowId, int quantite) {
        Cursor c = db.rawQuery("update listeuser set quantite = "+quantite+" where _id = "+rowId, new String[]{});
        return (c);
    }

    public Cursor barre(long rowId){
        Cursor c = db.rawQuery("update listeuser set barre = 1 where _id = "+rowId, new String[]{});
        return c;
    }

    public Cursor debarre(long rowId){
        Cursor c = db.rawQuery("update listeuser set barre = 0 where _id = "+rowId, new String[]{});
        return c;
    }

    public boolean exist(String table, String name){
        Cursor c = db.rawQuery("select * from "+table+" where nom = '"+name+"'", new String[]{});
        if (c == null){
            return false;
        }
        else{
            return true;
        }
    }


}
