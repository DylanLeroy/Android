package caddy2.com.projet;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Paint;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ArrayList<String> items = new ArrayList<String>();
    private ArrayList<Integer> quantites = new ArrayList<Integer>();
    private ArrayAdapter<String> aa;
    private ArrayAdapter<Integer> aa2;
    private BDD db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new BDD(this);
        db.open();
        aa = new ArrayAdapter<String>(this, R.layout.nom, items);
        aa2 = new ArrayAdapter<Integer>(this, android.R.layout.simple_list_item_1, quantites);
        ListView itemsList = (ListView) findViewById(R.id.ListeUser);
        ListView quantiteList = (ListView) findViewById(R.id.Quantites);

        itemsList.setAdapter(aa);
        quantiteList.setAdapter(aa2);

        /*TextView item = (TextView) findViewById(R.id.rowTextView);
        Cursor c2 = db.fetchItemByName(item.getText().toString(), "listeuser");

        if(Integer.valueOf(c2.getString(c2.getColumnIndex(db.KEY_BARRE)))==1) {
            item.setPaintFlags(item.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        }*/

        itemsList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //TextView item = itemsList.getItemAtPosition(position);

                TextView item2 = (TextView) view.findViewById(R.id.rowTextView);
                Cursor c3 = db.fetchItemByName(item2.getText().toString(), "listeuser");

                if(Integer.valueOf(c3.getString(c3.getColumnIndex(db.KEY_BARRE)))==0) {
                    item2.setPaintFlags(item2.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                    db.barre(Integer.valueOf(c3.getString(c3.getColumnIndex(db.KEY_ROWID))));
                }
                else{
                    item2.setPaintFlags(0);
                    db.debarre(Integer.valueOf(c3.getString(c3.getColumnIndex(db.KEY_ROWID))));
                }

            }

        });




        Cursor test = db.fetchItemwherebody0();
        String text = new String("");
        Integer id;
        Integer quantite;

        if (test.moveToFirst()){
            do{
                text = test.getString(test.getColumnIndex(db.KEY_NAME));
                quantite = Integer.valueOf(test.getString(test.getColumnIndex(db.KEY_QUANTITY)));
                id = Integer.valueOf(test.getString(test.getColumnIndex(db.KEY_ROWID)));
                quantites.add(0, quantite);
                items.add(0, text);
                aa.notifyDataSetChanged();
                aa2.notifyDataSetChanged();
            } while(test.moveToNext());
        }

    }

    public void deleteitem(long id){
        Cursor c = db.deleteitemuser(id);
    }


    private void deleteAllItems(){
        Cursor test = db.fetchAllItems("listeuser");
        if(test.moveToFirst()){
            do {
                Long id = Long.valueOf(test.getString(test.getColumnIndex(db.KEY_ROWID)));
                db.deleteitemuser(id);
            } while(test.moveToNext());
        }
        items.clear();
        quantites.clear();
        aa.notifyDataSetChanged();
        aa2.notifyDataSetChanged();
    }


    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.predef:
                Intent nouveauEcran = new Intent(MainActivity.this, PredefActivity.class);
                startActivity(nouveauEcran);
                return true;
            case R.id.deleteuser:
                deleteAllItems();
            default:
                return super.onOptionsItemSelected(item);
        }
    }






}
